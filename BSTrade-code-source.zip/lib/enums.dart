enum MenuState { home, favourite, publish, profile, login } //message
