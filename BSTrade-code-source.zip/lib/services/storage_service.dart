import 'dart:io';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:firebase_core/firebase_core.dart' as firebase_core;
import 'package:cloud_firestore/cloud_firestore.dart';

class Storage {
/**
@params:
  imageFile : fichier à stocker dans firebase storage
  idDocumentPourUpdateCollection : id du document afin d'enregistrer le chemin dans la collection utilisateur ou produit
  imagePourUnProduit : permet de savoir si c'est l'image d'un produit ou d'un utilisateur
  */

  Future<void> uploadImageDansCloudStorage(File imageFile, String idDocumentPourUpdateCollection, bool imagePourUnProduit) async {
    String nomDossierImage = '';
    String nomCollection = '';

    if (imagePourUnProduit == true) {
      nomDossierImage = 'imageProduit';
      nomCollection = 'products';
    } else {
      nomDossierImage = 'imageUtilisateur';
      nomCollection = 'users';
    }

    firebase_storage.FirebaseStorage _instanceCloudStorage = firebase_storage.FirebaseStorage.instanceFor(bucket: 'gs://treecorp-bstrade-project-app.appspot.com');
    // Je récupère la date et l'heure actuelle pour nommer mon image avec un nom unique
    var dateHeureLorsAppelFonction = DateTime.now();
    final String formatDateHeure = DateFormat('yyyy-MM-dd-H-m-s').format(dateHeureLorsAppelFonction);
    // je crée une chaine de caractère aléatoire pour être sur que le nom du fichier soit bien unique (cas ou 2 utilisateurs upload une image en même temps)
    const _listeCharacterePourIdAleatoire = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    Random _generateurNombreAleatoire = Random();

    String genererChaineAleatoirement(int length) => String.fromCharCodes(Iterable.generate(length, (_) => _listeCharacterePourIdAleatoire.codeUnitAt(_generateurNombreAleatoire.nextInt(_listeCharacterePourIdAleatoire.length))));

    final String nomImageDateHeureAvecChaineAleatoire = formatDateHeure + '-' + genererChaineAleatoirement(5);

    try {
      // J'uplaod l'image sur Firebase storage en donnant un nom unique à mon fichier afin d'éviter la réécriture de fichier
      await _instanceCloudStorage.ref('$nomDossierImage/$nomImageDateHeureAvecChaineAleatoire.png').putFile(imageFile);
      // j'update le champ permettant de sauvegarder le chemin de l'image
      FirebaseFirestore.instance
          .collection(nomCollection)
          .doc(idDocumentPourUpdateCollection)
          .update({
            'cheminImageCloudStorage': '$nomDossierImage/$nomImageDateHeureAvecChaineAleatoire.png'
          })
          .then((value) => print("L'ajout du chemin de l'image du produit a réussi"))
          .catchError((error) => print("Erreur dans l'ajout du chemin de l'image du produit: $error"));
    } on firebase_core.FirebaseException catch (e) {
      print(e.code);
    }
  }

  Future<String> recupererImageURL(String cheminImageCloudStorage) async {
    firebase_storage.FirebaseStorage _instanceCloudStorage = firebase_storage.FirebaseStorage.instanceFor(bucket: 'gs://treecorp-bstrade-project-app.appspot.com');
    String downloadURL = await _instanceCloudStorage.ref(cheminImageCloudStorage).getDownloadURL();

    return downloadURL;

    // Within your widgets:
    // Image.network(downloadURL);
  }

  void supprimerImage(String cheminImageCloudStorage) async {
    firebase_storage.FirebaseStorage _instanceCloudStorage = firebase_storage.FirebaseStorage.instanceFor(bucket: 'gs://treecorp-bstrade-project-app.appspot.com');

    try {
      await _instanceCloudStorage.ref(cheminImageCloudStorage).delete();
    } on firebase_core.FirebaseException catch (e) {
      print(e.code);
    }
  }
}
