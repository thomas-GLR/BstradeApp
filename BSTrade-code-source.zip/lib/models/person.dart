class Person {
  final String uid;

  Person({this.uid});
}
