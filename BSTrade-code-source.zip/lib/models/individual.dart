class Individual {
  final String name;
  //final List<String> favoriteId;
  //final List<String> adId;

  Individual({this.name}); //, this.favoriteId, this.adId});
}
